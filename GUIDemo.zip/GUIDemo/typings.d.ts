declare module '*.module.css';
